window["env"] = { 
  APP_PORTAL_HOST: "",
};
